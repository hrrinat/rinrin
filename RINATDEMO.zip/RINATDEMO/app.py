from flask import Flask, render_template, redirect, url_for, flash, request
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config
from models import db, User, Request, Review
from forms import RegistrationForm, LoginForm, RequestForm, ReviewForm

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'login'

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    with app.app_context():
        db.create_all()
        if not User.query.filter_by(username='admin').first():
            admin = User(
                username='admin',
                password=generate_password_hash('admin123'),
                is_admin=True,
                status='Активен'
            )
            db.session.add(admin)
            db.session.commit()

    # --- ROUTES ---

    @app.route('/')
    def index():
        slider_images = [
            url_for('static', filename='images/slide1.png'),
            url_for('static', filename='images/slide2.png'),
            url_for('static', filename='images/slide3.png')
        ]
        reviews = Review.query.order_by(Review.id.desc()).all()
        return render_template('index.html', slider_images=slider_images, reviews=reviews)

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        form = RegistrationForm()
        if form.validate_on_submit():
            hashed_pw = generate_password_hash(form.password.data)
            new_user = User(username=form.username.data, password=hashed_pw)
            db.session.add(new_user)
            db.session.commit()
            flash('Регистрация успешна! Теперь войдите.', 'success')
            return redirect(url_for('login'))
        return render_template('register.html', form=form)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        form = LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(username=form.username.data).first()
            if user and check_password_hash(user.password, form.password.data):
                if user.status == 'Заблокирован':
                    flash('Ваш аккаунт заблокирован. Обратитесь в поддержку.', 'danger')
                    return render_template('login.html', form=form)
                login_user(user)
                next_page = request.args.get('next')
                return redirect(next_page or url_for('index'))
            else:
                flash('Неверный логин или пароль. Если вы не зарегистрированы, пожалуйста, зарегистрируйтесь.', 'danger')
        return render_template('login.html', form=form)

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect(url_for('index'))

    @app.route('/dashboard')
    @login_required
    def dashboard():
        user_requests = Request.query.filter_by(user_id=current_user.id).order_by(Request.created_at.desc()).all()
        form = RequestForm()
        return render_template('dashboard.html', requests=user_requests, form=form)

    @app.route('/new_request', methods=['POST'])
    @login_required
    def new_request():
        form = RequestForm()
        if form.validate_on_submit():
            req = Request(
                title=form.title.data,
                description=form.description.data,
                user_id=current_user.id
            )
            db.session.add(req)
            db.session.commit()
            flash('Заявка отправлена!', 'success')
        return redirect(url_for('dashboard'))

    @app.route('/add_review/<int:req_id>', methods=['POST'])
    @login_required
    def add_review(req_id):
        req = Request.query.get_or_404(req_id)
        if req.user_id != current_user.id:
            flash('Нельзя оставить отзыв к чужой заявке', 'danger')
            return redirect(url_for('dashboard'))
        if req.status != 'Завершено':
            flash('Отзыв можно оставить только после завершения заявки', 'warning')
            return redirect(url_for('dashboard'))
        if req.review:
            flash('Отзыв уже оставлен', 'warning')
            return redirect(url_for('dashboard'))

        rating = request.form.get('rating', type=int)
        text = request.form.get('text')
        if rating and text:
            review = Review(text=text, rating=rating, request_id=req_id, user_id=current_user.id)
            db.session.add(review)
            db.session.commit()
            flash('Спасибо за отзыв!', 'success')
        return redirect(url_for('dashboard'))

    @app.route('/admin')
    @login_required
    def admin_panel():
        if not current_user.is_admin:
            flash('Доступ запрещен', 'danger')
            return redirect(url_for('index'))

        status_filter = request.args.get('status', '')
        sort_by = request.args.get('sort', 'created_at')
        query = Request.query
        if status_filter:
            query = query.filter_by(status=status_filter)
        if sort_by == 'status':
            query = query.order_by(Request.status)
        else:
            query = query.order_by(Request.created_at.desc())
        return render_template('admin.html', requests=query.all(), current_status=status_filter)

    @app.route('/update_status/<int:req_id>', methods=['POST'])
    @login_required
    def update_status(req_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))
        req = Request.query.get_or_404(req_id)
        req.status = request.form.get('status')
        db.session.commit()
        flash(f'Статус заявки #{req.id} изменен', 'info')
        return redirect(url_for('admin_panel'))

    @app.route('/admin/users')
    @login_required
    def admin_users():
        if not current_user.is_admin:
            flash('Доступ запрещен', 'danger')
            return redirect(url_for('index'))
        sort_by = request.args.get('sort', 'username')
        status_filter = request.args.get('status', '')
        query = User.query
        if status_filter:
            query = query.filter_by(status=status_filter)
        if sort_by == 'status':
            query = query.order_by(User.status)
        else:
            query = query.order_by(User.username)
        return render_template('admin_users.html', users=query.all(), current_status=status_filter, current_sort=sort_by)

    @app.route('/admin/update_user/<int:user_id>', methods=['POST'])
    @login_required
    def update_user(user_id):
        if not current_user.is_admin:
            return redirect(url_for('index'))
        user = User.query.get_or_404(user_id)
        if user.id == current_user.id:
            flash('Нельзя изменять настройки собственного аккаунта', 'warning')
            return redirect(url_for('admin_users'))
        new_status = request.form.get('status')
        new_role = request.form.get('role')
        if new_status in ['Активен', 'Заблокирован']:
            user.status = new_status
        if new_role in ['user', 'admin']:
            user.is_admin = (new_role == 'admin')
        db.session.commit()
        flash(f'Настройки пользователя {user.username} обновлены', 'success')
        return redirect(url_for('admin_users'))

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)